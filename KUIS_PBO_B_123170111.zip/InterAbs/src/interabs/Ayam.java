/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package interabs;

/**
 *
 * @author Adityo
 */
class Ayam implements Hewan {
     private String namaHewan;

    // create kucing without input parameter
    public Ayam() {
        this.namaHewan = "adalah Ayam";
    }

    // create kucing with parameter
    public Ayam(String namaHewan) {
        this.namaHewan = namaHewan;
    }

    @Override
  public void jenis() {
        System.out.println("adalah Ayam");
    }
   @Override
  public void suaraHewan() { 
        System.out.println("dengan bunyi a");
    }

@Override
    public String getNamaHewan() {
        return namaHewan;
    }
}
